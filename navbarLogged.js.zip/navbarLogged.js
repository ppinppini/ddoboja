export function createNavbar() {
    const navbarHTML = `
        <nav class="navbar">
            <div class="navbar-logo">
                <a href="/" class="logo-link">
                    <img src="images/logo.png" alt="logo" />
                </a>
            </div>
            <ul class="nav-items">
                <li class="nav-item"><a href="./history.html">공공 추모</a></li>
                <li class="nav-item"><a href="./products.html">추모공간</a></li>
                <li class="nav-item"><a href="#" id="openModalBtn">추모공간 생성</a></li>
            </ul>
            <div class="navbar-actions">
                <a href="mypage.html" class="btn">마이페이지</a>
                <div class="notification-icon" onclick="toggleNotifications()">
                    <img src="images/alram.png" alt="Notification Icon" width="24" height="24" />
                    <div class="notification-popup" id="notificationPopup">
                        <ul id="notificationList"></ul>
                    </div>
                </div>
            </div>
        </nav>

        <!-- 모달 -->
        <div id="myModal" class="modal">
            <div class="modal-content">
                <span class="close">&times;</span>
                <form id="myForm">
                    <label for="name">이름</label>
                    <input type="text" id="name" name="name">
                    <label for="birth">생년월일</label>
                    <input type="text" id="birth" name="birth">
                    <label for="deadDate">기일</label>
                    <input type="text" id="deadDate" name="deadDate">
                    <label for="comment">소개글</label>
                    <input type="text" id="comment" name="comment">
                    <label for="image">이미지 업로드</label>
                    <input type="file" id="image" name="image">
                    <input type="submit" value="생성">
                </form>
            </div>
        </div>
    `;

    document.getElementById("navbar").innerHTML = navbarHTML;

    const style = document.createElement("style");
    style.textContent = `
        .navbar {
            height: 10vh;
            background: #2c2c2c;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 0 20px;
            position: relative;
        }

        .navbar-logo {
            margin-right: auto; /* Pushes the logo to the left */
        }

        .navbar-logo .logo-link {
            text-decoration: none;
        }

        .navbar-logo img {
            width: 200px; 
        }

        .nav-items {
            display: flex;
            list-style: none;
            text-align: center;
            width: 70vw;
            justify-content: flex-end;
            margin-right: 2rem;
        }

        .nav-item {
            display: flex;
            align-items: center;
            height: 10vh;
        }

        .nav-item a {
            text-decoration: none;
            color: white;
            font-size: 1.1rem;
            margin-right: 2rem;
            padding: 6px 16px;
            border-radius: 5px;
        }

        .nav-item a:hover {
            background: gray;
        }

        .navbar-actions {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .btn {
            border: none;
            background: transparent;
            padding: 6px 16px;
            font-size: 1.1rem;
            color: white;
            background: #2c2c2c;
            border-radius: 5px;
            transition: 0.3s all ease-out;
            cursor: pointer;
            text-decoration: none;
        }

        .btn:hover {
            color: #2c2c2c;
            background: white;
        }

        .notification-icon {
            position: relative;
            cursor: pointer;
        }

        .notification-popup {
            display: none;
            position: absolute;
            top: 100%;
            right: 0;
            background: white;
            color: black;
            padding: 10px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
            width: 250px;
            z-index: 1000;
        }

        .notification-popup.show {
            display: block;
        }

        .notification-popup ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .notification-popup li {
            padding: 5px 0;
        }

        /* 모달 스타일 */
        .modal {
            display: none; /* 기본적으로 숨기기 */
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgb(0, 0, 0);
            background-color: rgba(0, 0, 0, 0.4);
            padding-top: 60px;
        }

        .modal-content {
            background-color: #fefefe;
            margin: 5% auto;
            padding: 20px;
            border: 1px solid #888;
            width: 80%;
        }

        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }

        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }
    `;
    document.head.appendChild(style);

    document.getElementById("openModalBtn").addEventListener("click", openModal);
    document.getElementsByClassName("close")[0].addEventListener("click", closeModal);
    window.addEventListener("click", outsideClick);
}

function toggleNotifications() {
    const popup = document.getElementById("notificationPopup");
    popup.style.display = popup.style.display === "block" ? "none" : "block";
}

window.toggleNotifications = toggleNotifications;

export function addNotification(message) {
    const notificationList = document.getElementById("notificationList");
    const li = document.createElement("li");
    li.textContent = message;
    notificationList.appendChild(li);
}

function openModal() {
    document.getElementById("myModal").style.display = "block";
}

function closeModal() {
    document.getElementById("myModal").style.display = "none";
}

function outsideClick(event) {
    if (event.target == document.getElementById("myModal")) {
        document.getElementById("myModal").style.display = "none";
    }
}

window.openModal = openModal;
window.closeModal = closeModal;
window.outsideClick = outsideClick;

// 폼 제출 이벤트 핸들러 추가
document.addEventListener("DOMContentLoaded", () => {
    document.getElementById("myForm").addEventListener("submit", function (e) {
        e.preventDefault(); // 기본 폼 제출 방지

        const formData = new FormData(this);

        // 데이터를 서버로 전송
        fetch("http://localhost:8080/forum", {
            method: "POST",
            body: formData,
        })
            .then((response) => response.json())
            .then((data) => {
                console.log("성공:", data);
                closeModal(); // 폼 제출 후 모달 닫기

                // 서버에서 받은 데이터를 사용하여 HTML 생성
                const newContent = document.createElement("div");
                newContent.innerHTML = `
                <img src="${data.imageUrl}" alt="">
                <span>${data.birth}</span>~<span>${data.deadDate}</span>
                <div>${data.comment}</div>
            `;
                document.getElementById("resultContainer").appendChild(newContent);
            })
            .catch((error) => {
                console.error("오류:", error);
            });

        // // 더미 데이터를 사용하여 결과 표시
        // const dummyData = {
        //     imageUrl: 'https://via.placeholder.com/150',
        //     birth: '1990-01-01',
        //     deadDate: '2020-01-01',
        //     comment: '소개글 예시'
        // };

        // console.log('성공:', dummyData);
        closeModal(); // 폼 제출 후 모달 닫기

        // 서버에서 받은 데이터를 사용하여 HTML 생성
        const newContent = document.createElement("div");
        newContent.innerHTML = `
            <img src="${dummyData.imageUrl}" alt="">
            <span>${dummyData.birth}</span>~<span>${dummyData.deadDate}</span>
            <div>${dummyData.comment}</div>
        `;
        document.getElementById("resultContainer").appendChild(newContent);
    });
});
